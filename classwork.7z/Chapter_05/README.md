## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 5: Basic Math and Stats with SQL

Covers arithmetic operations and introduces aggregate functions for finding sums, averages, and medians.



