## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 3: Understanding Data Types

Explains the definitions for setting columns in a table to hold specific types of data, from text to dates to various forms of numbers.

