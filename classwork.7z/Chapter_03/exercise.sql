--exercise 1
'We would use the numeric(3,1) data type 
because we are tracking the distance to the tenth of a mile (0,1) we 
 will have 1 number after the decimal 
 '
--exercise 2
'1 We use text data type for names
2 for sorting your data according to last name
'

--exercise 3
'
it will not be able to convert because theres no month included in the date
'
