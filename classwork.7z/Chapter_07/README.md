## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 7: Table Design that Works for You

Covers how to set up tables to improve the organization and integrity of your data as well as how to speed up queries using indexes.




