## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 8: Extracting Information by Grouping and Summarizing

Explains how to use aggregate functions to find trends in U.S. library use based on annual surveys.



