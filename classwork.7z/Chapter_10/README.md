## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 10: Statistical Functions in SQL

Introduces correlation, regression, and ranking functions in SQL to help you derive more meaning from data sets.

