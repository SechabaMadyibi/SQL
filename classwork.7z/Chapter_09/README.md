## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 9: Inspecting and Modifying Data

Explores how to  nd and  x incomplete or inaccurate data using a collection of records about meat, egg, and poultry producers as an example.

