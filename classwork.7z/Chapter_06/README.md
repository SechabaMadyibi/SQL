## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 6: Joining Tables in a Relational Database

Explains how to query multiple, related tables by joining them on key columns. You’ll learn how and when to use different types of joins.


