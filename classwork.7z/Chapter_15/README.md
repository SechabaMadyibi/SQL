## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 15: Saving Time with Views, Functions, and Triggers:

Explains how to automate database tasks so you can avoid repeating routine work.


