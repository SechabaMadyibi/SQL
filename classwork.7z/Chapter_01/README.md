## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 1: Creating Your First Database and Table

Introduces PostgreSQL, the pgAdmin user interface, and the code for loading a simple data set about teachers into a new database.

