## Practical SQL

[PracticalSQL](https://www.nostarch.com/practicalSQL) by Anthony DeBarros is [available from No Starch Press](https://www.nostarch.com/practicalSQL).

### Chapter 2: Beginning Data Exploration with `SELECT`

Explores basic SQL query syntax, including how to sort and filter data.



